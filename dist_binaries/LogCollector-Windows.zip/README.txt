LogCollector Standalone Application
======================================
This is a standalone version of the LogCollector application.

Getting Started:
1. Run LogCollector executable to start the application
2. Use 'LogCollector --service start'  to start the service
3. Use 'LogCollector --service stop'  to stop the service
4. Use 'LogCollector --service status'  to check service status

Data and logs are stored in the data/ and logs/ directories.

<Use 'LogCollector --h' for additional options>
